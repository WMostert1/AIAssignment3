How to run the file:
	1.) Navigate to the src folder in your terminal
	2.) Issue the command : javac *.java
	3.) Issue the command : java Main

Enjoy!