/**
 * Created by wernermostert on 2015/05/27.
 */
public class NetworkConfiguration {
    public int hiddenNodes = 0;
    public double momentum = 0.0;
    public double learningRate = 0.0;
    public int maxEpochs = 0;
}
