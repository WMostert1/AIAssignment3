/**
 * Created by wernermostert on 2015/05/24.
 */
public interface ActivationFunction {
    public double f(double net);
}
