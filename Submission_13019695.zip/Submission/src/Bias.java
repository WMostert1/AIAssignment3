/**
 * Created by wernermostert on 2015/05/24.
 */
public class Bias implements ActivationFunction {
    @Override
    public double f(double net) {
        return -1.0;
    }
}
